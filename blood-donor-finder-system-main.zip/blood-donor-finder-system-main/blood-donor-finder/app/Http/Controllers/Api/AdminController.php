<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Notification;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function pendingUsers()
    {
        $users = User::where('account_status', 'Pending')
            ->orderByDesc('id')
            ->get();

        return response()->json($users);
    }

    public function approveUser($id)
    {
        $user = User::findOrFail($id);
        $user->account_status = 'Approved';
        $user->save();

        Notification::create([
            'user_id' => $user->id,
            'title' => 'Account Approved',
            'message' => 'Your account has been approved by the admin.',
            'is_read' => false
        ]);

        return response()->json([
            'message' => 'User approved successfully',
            'user' => $user
        ]);
    }

    public function rejectUser(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $user->account_status = 'Rejected';
        $user->save();

        $reason = $request->reject_reason ?: 'Your account has been rejected by the admin.';

        Notification::create([
            'user_id' => $user->id,
            'title' => 'Account Rejected',
            'message' => $reason,
            'is_read' => false
        ]);

        return response()->json([
            'message' => 'User rejected successfully',
            'user' => $user
        ]);
    }

    public function pendingUsersView(Request $request)
    {
        $search = trim($request->search);

        $users = User::where('account_status', 'Pending')
            ->when($search, function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('user_code', 'like', "%{$search}%")
                      ->orWhere('name', 'like', "%{$search}%")
                      ->orWhere('first_name', 'like', "%{$search}%")
                      ->orWhere('middle_name', 'like', "%{$search}%")
                      ->orWhere('last_name', 'like', "%{$search}%")
                      ->orWhere('suffix', 'like', "%{$search}%")
                      ->orWhere('email', 'like', "%{$search}%");
                });
            })
            ->orderByDesc('id')
            ->paginate(10);

        $users->getCollection()->transform(function ($user) {
            $user->display_name = trim(implode(' ', array_filter([
                $user->first_name,
                $user->middle_name,
                $user->last_name,
                $user->suffix
            ])));

            if (empty($user->display_name)) {
                $user->display_name = $user->name;
            }

            return $user;
        });

        return view('admin.pending-users', compact('users'));
    }

    public function getPendingUsersData()
    {
        $pendingUsers = User::where('status', 'pending')->latest()->get();

        return response()->json([
            'count' => $pendingUsers->count(),
            'users' => $pendingUsers
        ]);
    }
}