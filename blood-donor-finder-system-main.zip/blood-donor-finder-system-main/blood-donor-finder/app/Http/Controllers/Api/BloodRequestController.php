<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BloodRequest;
use App\Models\User;
use App\Models\Notification;
use Illuminate\Http\Request;

class BloodRequestController extends Controller
{
    public function store(Request $request)
    {
        try {
            $request->validate([
                'requester_id' => 'required|exists:users,id',
                'blood_type' => 'required|string|max:10',
                'hospital_name' => 'required|string|max:255',
                'location' => 'required|string|max:255',
                'contact_number' => 'required|string|max:20',
                'urgency_level' => 'required|string|max:50',
                'notes' => 'nullable|string'
            ]);

            $user = User::findOrFail($request->requester_id);

            if ($user->account_status !== 'Approved') {
                return response()->json([
                    'message' => 'Only approved users can submit blood requests.',
                    'account_status' => $user->account_status
                ], 403);
            }

            $bloodRequest = BloodRequest::create([
                'requester_id' => $request->requester_id,
                'donor_id' => null,
                'blood_type' => $request->blood_type,
                'hospital_name' => $request->hospital_name,
                'location' => $request->location,
                'contact_number' => $request->contact_number,
                'urgency_level' => $request->urgency_level,
                'notes' => $request->notes,
                'status' => 'Pending'
            ]);

            $compatibleBloodTypes = $this->getCompatibleDonorTypes($request->blood_type);

            $matchingDonors = User::where('role', 'donor')
                ->where('account_status', 'Approved')
                ->where('availability', true)
                ->whereIn('blood_type', $compatibleBloodTypes)
                ->get();

            foreach ($matchingDonors as $donor) {
                Notification::create([
                    'user_id' => $donor->id,
                    'title' => 'New Blood Request',
                    'message' => 'A new blood request for blood type ' . $request->blood_type . ' has been posted near ' . $request->location . '.',
                    'type' => 'blood_request',
                    'reference_id' => $bloodRequest->id,
                    'is_read' => false
                ]);
            }

            return response()->json([
                'message' => 'Blood request submitted successfully',
                'data' => $bloodRequest,
                'compatible_donor_types' => $compatibleBloodTypes,
                'notified_donors_count' => $matchingDonors->count()
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Create failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function index()
    {
        $requests = BloodRequest::select(
            'id',
            'requester_id',
            'donor_id',
            'blood_type',
            'hospital_name',
            'location',
            'contact_number',
            'urgency_level',
            'notes',
            'status',
            'created_at',
            'updated_at'
        )->latest()->get();

        return response()->json($requests);
    }

    public function show($id)
    {
        $request = BloodRequest::select(
            'id',
            'requester_id',
            'donor_id',
            'blood_type',
            'hospital_name',
            'location',
            'contact_number',
            'urgency_level',
            'notes',
            'status',
            'created_at',
            'updated_at'
        )->findOrFail($id);

        return response()->json($request);
    }

    public function update(Request $request)
    {
        try {
            $request->validate([
                'request_id' => 'required|exists:blood_requests,id',
                'blood_type' => 'required|string|max:10',
                'hospital_name' => 'required|string|max:255',
                'location' => 'required|string|max:255',
                'contact_number' => 'required|string|max:20',
                'urgency_level' => 'required|string|max:50',
                'notes' => 'nullable|string'
            ]);

            $bloodRequest = BloodRequest::findOrFail($request->request_id);

            if (in_array($bloodRequest->status, ['Completed', 'Cancelled'])) {
                return response()->json([
                    'message' => 'This request can no longer be updated.'
                ], 400);
            }

            $bloodRequest->update([
                'blood_type' => $request->blood_type,
                'hospital_name' => $request->hospital_name,
                'location' => $request->location,
                'contact_number' => $request->contact_number,
                'urgency_level' => $request->urgency_level,
                'notes' => $request->notes,
            ]);

            return response()->json([
                'message' => 'Blood request updated successfully',
                'data' => $bloodRequest
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Update failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function destroy(Request $request)
    {
        try {
            $request->validate([
                'request_id' => 'required|exists:blood_requests,id'
            ]);

            $bloodRequest = BloodRequest::findOrFail($request->request_id);

            if ($bloodRequest->status === 'Completed') {
                return response()->json([
                    'message' => 'Completed requests cannot be deleted.'
                ], 400);
            }

            $bloodRequest->delete();

            return response()->json([
                'message' => 'Blood request deleted successfully'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Delete failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function acceptRequest(Request $request)
    {
        try {
            $request->validate([
                'request_id' => 'required|exists:blood_requests,id',
                'donor_id' => 'required|exists:users,id',
            ]);

            $bloodRequest = BloodRequest::findOrFail($request->request_id);
            $donor = User::findOrFail($request->donor_id);

            if ($donor->role !== 'donor') {
                return response()->json([
                    'message' => 'Only donor accounts can accept requests.'
                ], 403);
            }

            if ($donor->account_status !== 'Approved') {
                return response()->json([
                    'message' => 'Only approved donors can accept requests.'
                ], 403);
            }

            if (!$donor->availability) {
                return response()->json([
                    'message' => 'You are currently unavailable to donate.'
                ], 403);
            }

            if ($bloodRequest->status === 'Completed') {
                return response()->json([
                    'message' => 'This request is already completed.'
                ], 400);
            }

            if (!empty($bloodRequest->donor_id) && $bloodRequest->donor_id != $donor->id) {
                return response()->json([
                    'message' => 'This request has already been accepted by another donor.'
                ], 400);
            }

            $bloodRequest->update([
                'donor_id' => $donor->id,
                'status' => 'Accepted'
            ]);

            Notification::create([
                'user_id' => $bloodRequest->requester_id,
                'title' => 'Request Accepted',
                'message' => $donor->name . ' accepted your blood request for ' . $bloodRequest->blood_type . '.',
                'type' => 'request_accepted',
                'reference_id' => $bloodRequest->id,
                'is_read' => false
            ]);

            return response()->json([
                'message' => 'Blood request accepted successfully',
                'data' => $bloodRequest
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Accept request failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function markCompleted(Request $request)
    {
        try {
            $request->validate([
                'request_id' => 'required|exists:blood_requests,id'
            ]);

            $bloodRequest = BloodRequest::findOrFail($request->request_id);

            if ($bloodRequest->status === 'Completed') {
                return response()->json([
                    'message' => 'Already completed'
                ], 400);
            }

            if (empty($bloodRequest->donor_id)) {
                return response()->json([
                    'message' => 'No donor has accepted this request yet.'
                ], 400);
            }

            $bloodRequest->update([
                'status' => 'Completed'
            ]);

            $donor = User::findOrFail($bloodRequest->donor_id);
            $donor->increment('donor_points', 10);

            Notification::create([
                'user_id' => $donor->id,
                'title' => 'Donation Completed',
                'message' => 'You earned +10 points for completing a donation.',
                'type' => 'donation_completed',
                'reference_id' => $bloodRequest->id,
                'is_read' => false
            ]);

            return response()->json([
                'message' => 'Marked as completed + points awarded'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    private function getCompatibleDonorTypes($requestedBloodType)
    {
        $compatibilityMap = [
            'O-'  => ['O-'],
            'O+'  => ['O-', 'O+'],
            'A-'  => ['O-', 'A-'],
            'A+'  => ['O-', 'O+', 'A-', 'A+'],
            'B-'  => ['O-', 'B-'],
            'B+'  => ['O-', 'O+', 'B-', 'B+'],
            'AB-' => ['O-', 'A-', 'B-', 'AB-'],
            'AB+' => ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'],
        ];

        return $compatibilityMap[$requestedBloodType] ?? [];
    }
}