<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class DonorController extends Controller
{
    public function index()
    {
        $donors = User::where('role', 'donor')
            ->where('account_status', 'Approved')
            ->where('availability', true)
            ->get();

        return response()->json($donors);
    }

    public function search(Request $request)
    {
        $query = User::where('role', 'donor')
            ->where('account_status', 'Approved')
            ->where('availability', true);

        if ($request->blood_type) {
            $query->where('blood_type', $request->blood_type);
        }

        if ($request->location) {
            $query->where('location', 'like', '%' . $request->location . '%');
        }

        return response()->json($query->get());
    }

    public function updateAvailability(Request $request, $id)
    {
        $request->validate([
            'availability' => 'required|boolean'
        ]);

        $user = User::findOrFail($id);

        if ($user->account_status !== 'Approved') {
            return response()->json([
                'message' => 'Only approved donors can update availability.',
                'account_status' => $user->account_status
            ], 403);
        }

        if ($user->role !== 'donor') {
            return response()->json([
                'message' => 'Only donors can update availability.'
            ], 403);
        }

        $user->availability = $request->availability;
        $user->save();

        return response()->json([
            'message' => 'Availability updated successfully',
            'user' => $user
        ]);
    }
}