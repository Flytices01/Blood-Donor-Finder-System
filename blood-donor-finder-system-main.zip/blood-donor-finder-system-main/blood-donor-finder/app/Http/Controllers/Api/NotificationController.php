<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Notification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    private function formatDateTimeManila($dateTime)
    {
        return optional($dateTime)?->copy()?->timezone('Asia/Manila')?->format('Y-m-d h:i A');
    }

    public function index($userId)
    {
        $notifications = Notification::where('user_id', $userId)
            ->latest()
            ->get();

        $grouped = $notifications
            ->groupBy(function ($notification) {
                if (
                    strtolower((string) $notification->type) === 'chat' &&
                    !empty($notification->reference_id)
                ) {
                    return 'chat_' . $notification->reference_id;
                }

                return 'notification_' . $notification->id;
            })
            ->map(function ($group) use ($userId) {
                /** @var \App\Models\Notification $latest */
                $latest = $group->sortByDesc('created_at')->first();

                if (
                    strtolower((string) $latest->type) === 'chat' &&
                    !empty($latest->reference_id)
                ) {
                    $conversation = Conversation::with([
                        'requester:id,name,role,blood_type',
                        'donor:id,name,role,blood_type'
                    ])->find($latest->reference_id);

                    $otherUser = null;
                    if ($conversation) {
                        $otherUser = ((int) $conversation->requester_id === (int) $userId)
                            ? $conversation->donor
                            : $conversation->requester;
                    }

                    $unreadCount = $group->where('is_read', false)->count();
                    $isRead = $unreadCount === 0;

                    $title = $unreadCount > 1 ? 'New Messages' : 'New Message';

                    if ($unreadCount > 1) {
                        $message = ($otherUser?->name ?: 'Someone') . ' sent you ' . $unreadCount . ' new messages.';
                    } elseif ($unreadCount === 1) {
                        $message = $latest->message ?: (($otherUser?->name ?: 'Someone') . ' sent you a new message.');
                    } else {
                        $title = 'Chat';
                        $message = 'Open conversation with ' . ($otherUser?->name ?: 'User') . '.';
                    }

                    return [
                        'id' => $latest->id,
                        'user_id' => $latest->user_id,
                        'title' => $title,
                        'message' => $message,
                        'is_read' => $isRead ? 1 : 0,
                        'type' => 'chat',
                        'reference_id' => $latest->reference_id,
                        'message_count' => $unreadCount > 0 ? $unreadCount : $group->count(),
                        'other_user_name' => $otherUser?->name,
                        'other_user_role' => $otherUser?->role,
                        'other_user_blood_type' => $otherUser?->blood_type,
                        'created_at' => $this->formatDateTimeManila($latest->created_at),
                        'updated_at' => $this->formatDateTimeManila($latest->updated_at),
                    ];
                }

                return [
                    'id' => $latest->id,
                    'user_id' => $latest->user_id,
                    'title' => $latest->title,
                    'message' => $latest->message,
                    'is_read' => $latest->is_read ? 1 : 0,
                    'type' => $latest->type,
                    'reference_id' => $latest->reference_id,
                    'message_count' => 1,
                    'other_user_name' => null,
                    'other_user_role' => null,
                    'other_user_blood_type' => null,
                    'created_at' => $this->formatDateTimeManila($latest->created_at),
                    'updated_at' => $this->formatDateTimeManila($latest->updated_at),
                ];
            })
            ->sortByDesc(function ($item) {
                return strtotime($item['updated_at'] ?? $item['created_at'] ?? now()->toDateTimeString());
            })
            ->values();

        return response()->json($grouped);
    }

    public function markAsRead($id)
    {
        $notification = Notification::find($id);

        if (!$notification) {
            return response()->json([
                'success' => false,
                'message' => 'Notification not found'
            ], 404);
        }

        if (
            strtolower((string) $notification->type) === 'chat' &&
            !empty($notification->reference_id)
        ) {
            Notification::where('user_id', $notification->user_id)
                ->where('type', 'chat')
                ->where('reference_id', $notification->reference_id)
                ->where('is_read', false)
                ->update(['is_read' => true]);
        } else {
            $notification->is_read = true;
            $notification->save();
        }

        return response()->json([
            'success' => true,
            'message' => 'Notification marked as read'
        ]);
    }

    public function markAllAsRead($userId)
    {
        \App\Models\Notification::where('user_id', $userId)
            ->where('is_read', 0)
            ->update([
                'is_read' => 1,
                'updated_at' => now()
            ]);

        return response()->json([
            'success' => true,
            'message' => 'All notifications marked as read.'
        ]);
    }
}