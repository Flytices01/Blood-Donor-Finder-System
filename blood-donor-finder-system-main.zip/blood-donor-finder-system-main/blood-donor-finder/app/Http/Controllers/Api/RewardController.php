<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class RewardController extends Controller
{
    public function redeemReward(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
        ]);

        $user = User::findOrFail($request->user_id);

        if ($user->role !== 'donor') {
            return response()->json([
                'message' => 'Only donors can redeem rewards.'
            ], 403);
        }

        if ((int) $user->donor_points < 150) {
            return response()->json([
                'message' => 'You need at least 150 points to redeem this reward.'
            ], 400);
        }

        $voucherCode = 'BDF-HERO-REWARD-2026';

        $displayName = trim(implode(' ', array_filter([
            $user->first_name ?? null,
            $user->middle_name ?? null,
            $user->last_name ?? null,
            $user->suffix ?? null,
        ])));

        if (empty($displayName)) {
            $displayName = $user->name ?: 'Valued Donor';
        }

        $htmlMessage = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Blood Donor Finder Hero Donor Reward</title>
        </head>
        <body style="margin:0; padding:0; background-color:#f4f6f8; font-family:Arial, Helvetica, sans-serif;">
            <div style="width:100%; background-color:#f4f6f8; padding:30px 0;">
                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:700px; background:#ffffff; border-radius:14px; overflow:hidden; box-shadow:0 4px 14px rgba(0,0,0,0.08);">
                    
                    <tr>
                        <td style="background:linear-gradient(135deg, #b71c1c, #d32f2f); padding:32px 28px; text-align:center;">
                            <div style="font-size:28px; font-weight:bold; color:#ffffff; letter-spacing:0.5px;">
                                Blood Donor Finder
                            </div>
                            <div style="margin-top:8px; font-size:15px; color:#ffebee;">
                                Hero Donor Reward Notification
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td style="padding:32px 28px 18px 28px; color:#263238;">
                            <p style="margin:0 0 14px 0; font-size:16px;">
                                Hello <strong>' . e($displayName) . '</strong>,
                            </p>

                            <p style="margin:0 0 14px 0; font-size:15px; line-height:1.7;">
                                Congratulations for reaching <strong>150 donor points</strong> and becoming our
                                <strong>Hero Donor</strong>.
                            </p>

                            <p style="margin:0 0 18px 0; font-size:15px; line-height:1.7;">
                                Your generosity and willingness to help others make a big difference.
                                As part of our reward system, you may now claim your dummy reward voucher below.
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <td style="padding:0 28px 10px 28px;">
                            <div style="background:#fff5f5; border:2px dashed #d32f2f; border-radius:12px; padding:24px; text-align:center;">
                                <div style="font-size:13px; color:#b71c1c; font-weight:bold; letter-spacing:1px; text-transform:uppercase;">
                                    Reward Voucher Code
                                </div>
                                <div style="margin-top:12px; font-size:30px; font-weight:bold; color:#c62828; letter-spacing:2px;">
                                    ' . e($voucherCode) . '
                                </div>
                                <div style="margin-top:12px; font-size:14px; color:#546e7a;">
                                    Dummy reward for Hero Donor achievement
                                </div>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td style="padding:18px 28px 8px 28px;">
                            <div style="background:#f9fafb; border-radius:10px; padding:18px;">
                                <div style="font-size:15px; font-weight:bold; color:#263238; margin-bottom:8px;">
                                    Reward Details
                                </div>
                                <ul style="padding-left:18px; margin:0; color:#455a64; font-size:14px; line-height:1.8;">
                                    <li>Rank Achieved: <strong>Hero Donor</strong></li>
                                    <li>Points Reached: <strong>150 points</strong></li>
                                    <li>Reward Type: <strong>Dummy Voucher</strong></li>
                                    <li>Voucher Code: <strong>' . e($voucherCode) . '</strong></li>
                                </ul>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td style="padding:18px 28px 10px 28px; color:#37474f;">
                            <p style="margin:0 0 14px 0; font-size:14px; line-height:1.7;">
                                After successful redemption, your donor points are reset to the
                                <strong>Active Donor</strong> level so that you can continue earning points and rewards again.
                            </p>

                            <p style="margin:0; font-size:14px; line-height:1.7;">
                                Thank you for helping save lives through blood donation and for supporting our mission.
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <td style="padding:24px 28px; text-align:center; background:#fafafa; border-top:1px solid #eeeeee;">
                            <div style="font-size:13px; color:#78909c; line-height:1.6;">
                                This is an automated email from <strong>Blood Donor Finder</strong>.<br>
                                Please keep this message for your record.
                            </div>
                        </td>
                    </tr>

                </table>
            </div>
        </body>
        </html>';

        Mail::html($htmlMessage, function ($message) use ($user) {
            $message->to($user->email)
                ->subject('Blood Donor Finder Hero Donor Reward');
        });

        $user->donor_points = 10; // balik sa Active Donor
        $user->save();

        Notification::create([
            'user_id' => $user->id,
            'title' => 'Reward Redeemed',
            'message' => 'Your Hero Donor reward has been sent to your email. Your donor points have been reset to Active Donor.',
            'is_read' => false
        ]);

        return response()->json([
            'message' => 'Reward redeemed successfully. Check your email.',
            'donor_points' => $user->donor_points
        ]);
    }
}