<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BloodRequest;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    private function formatDateTimeManila($dateTime)
    {
        return optional($dateTime)?->copy()?->timezone('Asia/Manila')?->format('Y-m-d H:i:s');
    }

    public function getOrCreateConversation(Request $request)
    {
        try {
            $request->validate([
                'blood_request_id' => 'required|exists:blood_requests,id',
                'user_id' => 'required|exists:users,id',
            ]);

            $bloodRequest = BloodRequest::findOrFail($request->blood_request_id);
            $userId = (int) $request->user_id;

            if (empty($bloodRequest->donor_id)) {
                return response()->json([
                    'success' => false,
                    'message' => 'No donor has accepted this request yet.'
                ], 400);
            }

            if (
                $userId !== (int) $bloodRequest->requester_id &&
                $userId !== (int) $bloodRequest->donor_id
            ) {
                return response()->json([
                    'success' => false,
                    'message' => 'You are not allowed to access this conversation.'
                ], 403);
            }

            $conversation = Conversation::firstOrCreate(
                ['blood_request_id' => $bloodRequest->id],
                [
                    'requester_id' => $bloodRequest->requester_id,
                    'donor_id' => $bloodRequest->donor_id,
                ]
            );

            $otherUser = $userId === (int) $bloodRequest->requester_id
                ? User::find($bloodRequest->donor_id)
                : User::find($bloodRequest->requester_id);

            return response()->json([
                'success' => true,
                'message' => 'Conversation ready.',
                'chat_closed' => strtolower((string) $bloodRequest->status) === 'completed',
                'conversation' => [
                    'id' => $conversation->id,
                    'blood_request_id' => $conversation->blood_request_id,
                    'requester_id' => $conversation->requester_id,
                    'donor_id' => $conversation->donor_id,
                    'other_user_id' => $otherUser?->id,
                    'other_user_name' => $otherUser?->name,
                    'other_user_role' => $otherUser?->role,
                    'other_user_blood_type' => $otherUser?->blood_type,
                    'created_at' => $this->formatDateTimeManila($conversation->created_at),
                    'updated_at' => $this->formatDateTimeManila($conversation->updated_at),
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create or load conversation.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function getChatList(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);

            $userId = (int) $request->user_id;

            $conversations = Conversation::with([
                'requester:id,name,role,blood_type,profile_picture',
                'donor:id,name,role,blood_type,profile_picture',
                'bloodRequest:id,blood_type,hospital_name,location,urgency_level,status',
                'latestMessage'
            ])
                ->where(function ($q) use ($userId) {
                    $q->where('requester_id', $userId)
                        ->orWhere('donor_id', $userId);
                })
                ->orderByDesc('updated_at')
                ->get()
                ->map(function ($conversation) use ($userId) {
                    $otherUser = $conversation->requester_id === $userId
                        ? $conversation->donor
                        : $conversation->requester;

                    $unreadCount = Message::where('conversation_id', $conversation->id)
                        ->where('receiver_id', $userId)
                        ->where('is_read', false)
                        ->count();

                    return [
                        'id' => $conversation->id,
                        'blood_request_id' => $conversation->blood_request_id,
                        'other_user_id' => $otherUser?->id,
                        'other_user_name' => $otherUser?->name,
                        'other_user_role' => $otherUser?->role,
                        'other_user_blood_type' => $otherUser?->blood_type,
                        'other_user_profile_picture' => $otherUser?->profile_picture,
                        'request_blood_type' => $conversation->bloodRequest?->blood_type,
                        'hospital_name' => $conversation->bloodRequest?->hospital_name,
                        'location' => $conversation->bloodRequest?->location,
                        'urgency_level' => $conversation->bloodRequest?->urgency_level,
                        'request_status' => $conversation->bloodRequest?->status,
                        'chat_closed' => strtolower((string) ($conversation->bloodRequest?->status ?? '')) === 'completed',
                        'last_message' => $conversation->latestMessage?->message,
                        'last_message_time' => $this->formatDateTimeManila($conversation->latestMessage?->created_at),
                        'unread_count' => $unreadCount,
                        'updated_at' => $this->formatDateTimeManila($conversation->updated_at),
                    ];
                });

            return response()->json([
                'success' => true,
                'conversations' => $conversations
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to load chat list.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function getMessages(Request $request, $conversationId)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);

            $conversation = Conversation::findOrFail($conversationId);
            $userId = (int) $request->user_id;

            if ($conversation->requester_id !== $userId && $conversation->donor_id !== $userId) {
                return response()->json([
                    'success' => false,
                    'message' => 'You are not allowed to view these messages.'
                ], 403);
            }

            $bloodRequest = BloodRequest::find($conversation->blood_request_id);
            $chatClosed = $bloodRequest && strtolower((string) $bloodRequest->status) === 'completed';

            $messages = Message::where('conversation_id', $conversation->id)
                ->orderBy('created_at', 'asc')
                ->get()
                ->map(function ($message) {
                    return [
                        'id' => $message->id,
                        'conversation_id' => $message->conversation_id,
                        'sender_id' => $message->sender_id,
                        'receiver_id' => $message->receiver_id,
                        'message' => $message->message,
                        'is_read' => $message->is_read,
                        'created_at' => $this->formatDateTimeManila($message->created_at),
                    ];
                });

            return response()->json([
                'success' => true,
                'chat_closed' => $chatClosed,
                'message' => $chatClosed
                    ? 'Chat is closed because this blood request is already completed.'
                    : 'Messages loaded successfully.',
                'messages' => $messages
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to load messages.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function sendMessage(Request $request, $conversationId)
    {
        try {
            $request->validate([
                'sender_id' => 'required|exists:users,id',
                'message' => 'required|string|max:2000',
            ]);

            $conversation = Conversation::findOrFail($conversationId);
            $senderId = (int) $request->sender_id;

            if ($conversation->requester_id !== $senderId && $conversation->donor_id !== $senderId) {
                return response()->json([
                    'success' => false,
                    'message' => 'You are not allowed to send messages in this chat.'
                ], 403);
            }

            $bloodRequest = BloodRequest::find($conversation->blood_request_id);
            if ($bloodRequest && strtolower((string) $bloodRequest->status) === 'completed') {
                return response()->json([
                    'success' => false,
                    'message' => 'Chat is closed because this blood request is already completed.'
                ], 403);
            }

            $receiverId = $conversation->requester_id === $senderId
                ? $conversation->donor_id
                : $conversation->requester_id;

            $msg = Message::create([
                'conversation_id' => $conversation->id,
                'sender_id' => $senderId,
                'receiver_id' => $receiverId,
                'message' => trim($request->message),
                'is_read' => false,
            ]);

            $conversation->touch();

            $sender = User::find($senderId);

            if ($sender) {
                $senderRole = strtolower($sender->role ?? 'user');
                $senderName = $sender->name ?? 'Someone';

                if ($senderRole === 'donor') {
                    $notifMessage = $senderName . ' sent you a message regarding your blood request';
                } elseif ($senderRole === 'requester') {
                    $notifMessage = $senderName . ' sent you a message regarding an accepted blood request';
                } else {
                    $notifMessage = $senderName . ' sent you a new message';
                }

                if ($bloodRequest && !empty($bloodRequest->blood_type)) {
                    $notifMessage .= ' (' . $bloodRequest->blood_type . ')';
                }

                $notifMessage .= '.';

                Notification::create([
                    'user_id' => $receiverId,
                    'title' => 'New Message',
                    'message' => $notifMessage,
                    'type' => 'chat',
                    'reference_id' => $conversation->id,
                    'is_read' => false,
                ]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Message sent successfully.',
                'message_data' => [
                    'id' => $msg->id,
                    'conversation_id' => $msg->conversation_id,
                    'sender_id' => $msg->sender_id,
                    'receiver_id' => $msg->receiver_id,
                    'message' => $msg->message,
                    'is_read' => $msg->is_read,
                    'created_at' => $this->formatDateTimeManila($msg->created_at),
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to send message.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function markAsRead(Request $request, $conversationId)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);

            $conversation = Conversation::findOrFail($conversationId);
            $userId = (int) $request->user_id;

            if ($conversation->requester_id !== $userId && $conversation->donor_id !== $userId) {
                return response()->json([
                    'success' => false,
                    'message' => 'You are not allowed to update these messages.'
                ], 403);
            }

            Message::where('conversation_id', $conversation->id)
                ->where('receiver_id', $userId)
                ->where('is_read', false)
                ->update(['is_read' => true]);

            return response()->json([
                'success' => true,
                'message' => 'Messages marked as read.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to mark messages as read.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function unreadCount(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
            ]);

            $userId = (int) $request->user_id;

            $count = Message::where('receiver_id', $userId)
                ->where('is_read', false)
                ->count();

            return response()->json([
                'success' => true,
                'unread_count' => $count
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to load unread count.',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}