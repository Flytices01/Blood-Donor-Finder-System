<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Notification;
use App\Models\EmailOtp;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\ValidationException;
use Carbon\Carbon;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        try {
            $request->validate([
                'first_name' => 'required|string|max:100',
                'middle_name' => 'nullable|string|max:100',
                'last_name' => 'required|string|max:100',
                'suffix' => 'nullable|string|max:20',
                'age' => 'required|integer|min:18|max:100',
                'email' => 'required|email|unique:users,email',
                'password' => [
                    'required',
                    'string',
                    'min:8',
                    'regex:/[A-Z]/',
                    'regex:/[^A-Za-z0-9]/'
                ],
                'role' => 'required|in:donor,requester',
                'blood_type' => 'required|in:A+,A-,B+,B-,AB+,AB-,O+,O-',
                'phone' => 'required|string|max:20|unique:users,phone',
                'location' => 'required|string|max:255',
                'id_image' => 'required|image|mimes:jpg,jpeg,png|max:10240',
                'selfie_image' => 'required|image|mimes:jpg,jpeg,png|max:10240',
                'blood_type_test_result' => 'required|image|mimes:jpg,jpeg,png|max:10240',
            ], [
                'email.unique' => 'This email is already registered.',
                'phone.unique' => 'This phone number is already registered.',
                'password.min' => 'Password must be at least 8 characters.',
                'password.regex' => 'Password must contain at least 1 capital letter and 1 special character.',
                'age.min' => 'Age must be at least 18 years old.',
            ]);

            $idImagePath = null;
            $selfieImagePath = null;
            $bloodTypeTestResultPath = null;

            if ($request->hasFile('id_image')) {
                $idImagePath = $request->file('id_image')->store('uploads/id_images', 'public');
            }

            if ($request->hasFile('selfie_image')) {
                $selfieImagePath = $request->file('selfie_image')->store('uploads/selfie_images', 'public');
            }

            if ($request->hasFile('blood_type_test_result')) {
                $bloodTypeTestResultPath = $request->file('blood_type_test_result')->store('uploads/blood_type_test_results', 'public');
            }

            $fullName = $this->buildFullName(
                $request->first_name,
                $request->middle_name,
                $request->last_name,
                $request->suffix
            );

            $user = User::create([
                'name' => $fullName,
                'first_name' => $request->first_name,
                'middle_name' => $request->middle_name,
                'last_name' => $request->last_name,
                'suffix' => $request->suffix,
                'age' => $request->age,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'role' => $request->role,
                'blood_type' => $request->blood_type,
                'phone' => $request->phone,
                'location' => $request->location,
                'id_image' => $idImagePath,
                'selfie_image' => $selfieImagePath,
                'blood_type_test_result' => $bloodTypeTestResultPath,
                'profile_picture' => null,
                'donor_points' => 0,
                'account_status' => 'Pending',
                'availability' => true,
                'is_email_verified' => false
            ]);

            $user->user_code = 'BDF-' . date('Y') . '-' . str_pad($user->id, 4, '0', STR_PAD_LEFT);
            $user->save();

            $otpCode = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

            EmailOtp::where('email', $user->email)
                ->where('purpose', 'register')
                ->where('is_used', false)
                ->update(['is_used' => true]);

            EmailOtp::create([
                'user_id' => $user->id,
                'email' => $user->email,
                'otp_code' => $otpCode,
                'purpose' => 'register',
                'expires_at' => Carbon::now()->addMinutes(5),
                'is_used' => false,
            ]);

            Mail::raw(
                "Your Blood Donor Finder OTP code is: {$otpCode}. This code will expire in 5 minutes.",
                function ($message) use ($user) {
                    $message->to($user->email)
                        ->subject('Blood Donor Finder Registration OTP');
                }
            );

            $admins = User::where('role', 'admin')->get();

            foreach ($admins as $admin) {
                Notification::create([
                    'user_id' => $admin->id,
                    'title' => 'New User Registration',
                    'message' => $user->name . ' (' . $user->user_code . ') registered and is waiting for approval.',
                    'is_read' => false
                ]);
            }

            return response()->json([
                'message' => 'Registration successful. OTP sent to email.',
                'user_id' => $user->id,
                'email' => $user->email
            ], 201);

        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Registration failed.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function sendRegisterOtp(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email|exists:users,email'
            ]);

            $user = User::where('email', $request->email)->first();

            $otpCode = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

            EmailOtp::where('email', $user->email)
                ->where('purpose', 'register')
                ->where('is_used', false)
                ->update(['is_used' => true]);

            EmailOtp::create([
                'user_id' => $user->id,
                'email' => $user->email,
                'otp_code' => $otpCode,
                'purpose' => 'register',
                'expires_at' => Carbon::now()->addMinutes(5),
                'is_used' => false,
            ]);

            Mail::raw(
                "Your Blood Donor Finder OTP code is: {$otpCode}. This code will expire in 5 minutes.",
                function ($message) use ($user) {
                    $message->to($user->email)
                        ->subject('Blood Donor Finder Registration OTP');
                }
            );

            return response()->json([
                'message' => 'OTP sent successfully.'
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to send OTP.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function verifyRegisterOtp(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email',
                'otp_code' => 'required|string|size:6',
            ]);

            $otp = EmailOtp::where('email', $request->email)
                ->where('purpose', 'register')
                ->where('otp_code', $request->otp_code)
                ->where('is_used', false)
                ->latest()
                ->first();

            if (!$otp) {
                return response()->json(['message' => 'Invalid OTP.'], 400);
            }

            if (Carbon::now()->gt($otp->expires_at)) {
                return response()->json(['message' => 'OTP has expired.'], 400);
            }

            $otp->is_used = true;
            $otp->save();

            $user = User::where('email', $request->email)->first();
            if ($user) {
                $user->is_email_verified = true;
                $user->save();
            }

            return response()->json([
                'message' => 'OTP verified successfully.'
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'OTP verification failed.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function sendForgotPasswordOtp(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email|exists:users,email',
            ]);

            $user = User::where('email', $request->email)->first();

            $otpCode = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

            EmailOtp::where('email', $user->email)
                ->where('purpose', 'forgot_password')
                ->where('is_used', false)
                ->update(['is_used' => true]);

            EmailOtp::create([
                'user_id' => $user->id,
                'email' => $user->email,
                'otp_code' => $otpCode,
                'purpose' => 'forgot_password',
                'expires_at' => Carbon::now()->addMinutes(5),
                'is_used' => false,
            ]);

            Mail::raw(
                "Your Blood Donor Finder password reset OTP is: {$otpCode}. This code will expire in 5 minutes.",
                function ($message) use ($user) {
                    $message->to($user->email)
                        ->subject('Blood Donor Finder Password Reset OTP');
                }
            );

            return response()->json([
                'message' => 'Forgot password OTP sent successfully.'
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to send forgot password OTP.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function verifyForgotPasswordOtp(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email|exists:users,email',
                'otp_code' => 'required|string|size:6',
                'new_password' => [
                    'required',
                    'string',
                    'min:8',
                    'same:confirm_password',
                    'regex:/[A-Z]/',
                    'regex:/[^A-Za-z0-9]/'
                ],
                'confirm_password' => 'required|min:8',
            ], [
                'new_password.min' => 'Password must be at least 8 characters.',
                'new_password.regex' => 'Password must contain at least 1 capital letter and 1 special character.',
            ]);

            $user = User::where('email', $request->email)->first();

            $otp = EmailOtp::where('user_id', $user->id)
                ->where('email', $user->email)
                ->where('purpose', 'forgot_password')
                ->where('otp_code', $request->otp_code)
                ->where('is_used', false)
                ->latest()
                ->first();

            if (!$otp) {
                return response()->json([
                    'message' => 'Invalid OTP.'
                ], 400);
            }

            if (Carbon::now()->gt($otp->expires_at)) {
                return response()->json([
                    'message' => 'OTP has expired.'
                ], 400);
            }

            $user->password = Hash::make($request->new_password);
            $user->save();

            $otp->is_used = true;
            $otp->save();

            EmailOtp::where('user_id', $user->id)
                ->where('purpose', 'forgot_password')
                ->where('is_used', false)
                ->update(['is_used' => true]);

            return response()->json([
                'message' => 'Password reset successful.'
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to verify forgot password OTP.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function sendChangePasswordOtp(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
                'email' => 'required|email',
                'current_password' => 'required',
            ]);

            $user = User::findOrFail($request->user_id);

            if ($user->email !== $request->email) {
                return response()->json([
                    'message' => 'Email does not match the logged-in user.'
                ], 400);
            }

            if (!Hash::check($request->current_password, $user->password)) {
                return response()->json([
                    'message' => 'Current password is incorrect.'
                ], 400);
            }

            EmailOtp::where('user_id', $user->id)
                ->where('purpose', 'change_password')
                ->where('is_used', false)
                ->update(['is_used' => true]);

            $otpCode = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

            EmailOtp::create([
                'user_id' => $user->id,
                'email' => $user->email,
                'otp_code' => $otpCode,
                'purpose' => 'change_password',
                'expires_at' => Carbon::now()->addMinutes(5),
                'is_used' => false,
            ]);

            Mail::raw(
                "Your Blood Donor Finder change password OTP is: {$otpCode}. This code will expire in 5 minutes.",
                function ($message) use ($user) {
                    $message->to($user->email)
                        ->subject('Blood Donor Finder Change Password OTP');
                }
            );

            return response()->json([
                'message' => 'Change password OTP sent successfully.'
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to send change password OTP.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function verifyChangePasswordOtp(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
                'email' => 'required|email',
                'current_password' => 'required',
                'otp_code' => 'required|string|size:6',
                'new_password' => [
                    'required',
                    'string',
                    'min:8',
                    'same:confirm_password',
                    'regex:/[A-Z]/',
                    'regex:/[^A-Za-z0-9]/'
                ],
                'confirm_password' => 'required|min:8',
            ], [
                'new_password.min' => 'Password must be at least 8 characters.',
                'new_password.regex' => 'Password must contain at least 1 capital letter and 1 special character.',
            ]);

            $user = User::findOrFail($request->user_id);

            if ($user->email !== $request->email) {
                return response()->json([
                    'message' => 'Email does not match the logged-in user.'
                ], 400);
            }

            if (!Hash::check($request->current_password, $user->password)) {
                return response()->json([
                    'message' => 'Current password is incorrect.'
                ], 400);
            }

            $otp = EmailOtp::where('user_id', $user->id)
                ->where('email', $user->email)
                ->where('purpose', 'change_password')
                ->where('otp_code', $request->otp_code)
                ->where('is_used', false)
                ->latest()
                ->first();

            if (!$otp) {
                return response()->json([
                    'message' => 'Invalid OTP.'
                ], 400);
            }

            if (Carbon::now()->gt($otp->expires_at)) {
                return response()->json([
                    'message' => 'OTP has expired.'
                ], 400);
            }

            $user->password = Hash::make($request->new_password);
            $user->save();

            $otp->is_used = true;
            $otp->save();

            EmailOtp::where('user_id', $user->id)
                ->where('purpose', 'change_password')
                ->where('is_used', false)
                ->update(['is_used' => true]);

            return response()->json([
                'message' => 'Password changed successfully.'
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to verify change password OTP.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function login(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email',
                'password' => 'required'
            ]);

            $user = User::where('email', $request->email)->first();

            if (!$user || !Hash::check($request->password, $user->password)) {
                return response()->json([
                    'message' => 'Invalid credentials'
                ], 401);
            }

            if (!$user->is_email_verified) {
                return response()->json([
                    'message' => 'Please verify your email first.'
                ], 403);
            }

            return response()->json([
                'message' => 'Login successful',
                'user' => $user,
                'account_status' => $user->account_status
            ]);

        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Login failed.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function updatePhoneNumber(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
                'phone' => 'required|string|max:20|unique:users,phone,' . $request->user_id
            ], [
                'phone.unique' => 'This phone number is already registered.'
            ]);

            $user = User::findOrFail($request->user_id);
            $user->phone = $request->phone;
            $user->save();

            return response()->json([
                'message' => 'Phone number updated successfully.',
                'user' => $user
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to update phone number.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function changePassword(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
                'current_password' => 'required',
                'new_password' => [
                    'required',
                    'string',
                    'min:8',
                    'same:confirm_password',
                    'regex:/[A-Z]/',
                    'regex:/[^A-Za-z0-9]/'
                ],
                'confirm_password' => 'required|min:8'
            ], [
                'new_password.min' => 'Password must be at least 8 characters.',
                'new_password.regex' => 'Password must contain at least 1 capital letter and 1 special character.',
            ]);

            $user = User::findOrFail($request->user_id);

            if (!Hash::check($request->current_password, $user->password)) {
                return response()->json([
                    'message' => 'Current password is incorrect.'
                ], 400);
            }

            $user->password = Hash::make($request->new_password);
            $user->save();

            return response()->json([
                'message' => 'Password changed successfully.'
            ]);

        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to change password.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function uploadProfilePicture(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
                'image' => 'required|image|mimes:jpg,jpeg,png|max:10240',
            ]);

            $user = User::findOrFail($request->user_id);

            if ($request->hasFile('image')) {
                $path = $request->file('image')->store('uploads/profile_pictures', 'public');

                $user->profile_picture = $path;
                $user->save();

                return response()->json([
                    'success' => true,
                    'message' => 'Profile picture uploaded successfully.',
                    'profile_picture' => $path
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => 'No image uploaded.'
            ], 400);

        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Profile picture upload failed.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function forgotPassword(Request $request)
    {
        return response()->json([
            'message' => 'Use OTP-based forgot password flow.'
        ], 400);
    }

    public function getUserProfile($id)
    {
        try {
            $user = User::findOrFail($id);

            return response()->json([
                'message' => 'User profile fetched successfully.',
                'user' => $user
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to fetch user profile.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    private function buildFullName($firstName, $middleName, $lastName, $suffix = null)
    {
        return trim(implode(' ', array_filter([
            $firstName,
            $middleName,
            $lastName,
            $suffix
        ])));
    }
}