<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\BloodRequest;
use App\Models\Notification;
use App\Models\EmailOtp;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Mail;

class AdminWebController extends Controller
{
    public function showLogin()
    {
        return view('admin.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $admin = User::where('email', $request->email)
            ->where('role', 'admin')
            ->first();

        if (!$admin || !Hash::check($request->password, $admin->password)) {
            return back()->with('error', 'Invalid admin credentials.');
        }

        if ($admin->account_status !== 'Approved') {
            return back()->with('error', 'Admin account is not approved.');
        }

        Session::put('admin_id', $admin->id);
        Session::put('admin_name', $admin->name);
        Session::put('admin_email', $admin->email);

        return redirect('/admin/dashboard');
    }

    public function logout()
    {
        Session::forget('admin_id');
        Session::forget('admin_name');
        Session::forget('admin_email');

        return redirect('/admin/login');
    }

    public function dashboard()
    {
        $this->checkAdminSession();

        $totalUsers = User::count();
        $pendingUsers = User::where('account_status', 'Pending')->count();
        $approvedUsers = User::where('account_status', 'Approved')->count();
        $bloodRequests = BloodRequest::count();
        $donors = User::where('role', 'donor')->count();
        $notifications = Notification::where('user_id', Session::get('admin_id'))->count();

        return view('admin.dashboard', compact(
            'totalUsers',
            'pendingUsers',
            'approvedUsers',
            'bloodRequests',
            'donors',
            'notifications'
        ));
    }

    public function pendingUsers(Request $request)
    {
        $search = trim($request->search);

        $users = User::where('account_status', 'Pending')
            ->when($search, function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('user_code', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%")
                    ->orWhere('first_name', 'like', "%{$search}%")
                    ->orWhere('middle_name', 'like', "%{$search}%")
                    ->orWhere('last_name', 'like', "%{$search}%")
                    ->orWhere('suffix', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%");
                });
            })
            ->orderByDesc('id')
            ->paginate(10);

        $users->getCollection()->transform(function ($user) {
            $user->display_name = trim(implode(' ', array_filter([
                $user->first_name,
                $user->middle_name,
                $user->last_name,
                $user->suffix
            ])));

            if (empty($user->display_name)) {
                $user->display_name = $user->name;
            }

            return $user;
        });

        return view('admin.pending-users', compact('users'));
    }

    public function bloodRequests(Request $request)
    {
        $this->checkAdminSession();

        $query = BloodRequest::with('requester')->latest();

        if ($request->search) {
            $search = $request->search;

            $query->where(function ($q) use ($search) {
                $q->where('blood_type', 'like', "%$search%")
                    ->orWhere('hospital_name', 'like', "%$search%")
                    ->orWhere('location', 'like', "%$search%")
                    ->orWhere('contact_number', 'like', "%$search%")
                    ->orWhere('urgency_level', 'like', "%$search%")
                    ->orWhere('status', 'like', "%$search%")
                    ->orWhereHas('requester', function ($rq) use ($search) {
                        $rq->where('name', 'like', "%$search%")
                            ->orWhere('user_code', 'like', "%$search%");
                    });
            });
        }

        $requests = $query->paginate(10)->withQueryString();

        return view('admin.blood-requests', compact('requests'));
    }

    public function donors(Request $request)
    {
        $this->checkAdminSession();

        $query = User::where('role', 'donor')->latest();

        if ($request->search) {
            $search = $request->search;

            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%$search%")
                    ->orWhere('email', 'like', "%$search%")
                    ->orWhere('blood_type', 'like', "%$search%")
                    ->orWhere('phone', 'like', "%$search%")
                    ->orWhere('location', 'like', "%$search%")
                    ->orWhere('account_status', 'like', "%$search%")
                    ->orWhere('user_code', 'like', "%$search%");
            });
        }

        $donors = $query->paginate(10)->withQueryString();

        return view('admin.donors', compact('donors'));
    }

    public function approveUser($id)
    {
        $this->checkAdminSession();

        $user = User::findOrFail($id);
        $user->account_status = 'Approved';
        $user->save();

        Notification::create([
            'user_id' => $user->id,
            'title' => 'Account Approved',
            'message' => 'Your account has been approved by the admin.'
        ]);

        return redirect('/admin/pending-users')->with('success', 'User approved successfully.');
    }

    public function rejectUser(Request $request, $id)
    {
        $this->checkAdminSession();

        $request->validate([
            'reject_reason' => 'required|string|max:255'
        ]);

        $user = User::findOrFail($id);
        $user->account_status = 'Rejected';
        $user->save();

        Notification::create([
            'user_id' => $user->id,
            'title' => 'Account Rejected',
            'message' => 'Your account has been rejected by the admin. Reason: ' . $request->reject_reason
        ]);

        return redirect('/admin/pending-users')->with('success', 'User rejected successfully.');
    }

    public function showChangePassword()
    {
        $this->checkAdminSession();
        return view('admin.change-password');
    }

    public function sendChangePasswordOtp(Request $request)
    {
        $this->checkAdminSession();

        $request->validate([
            'current_password' => 'required',
        ]);

        $admin = User::where('id', Session::get('admin_id'))
            ->where('role', 'admin')
            ->first();

        if (!$admin) {
            return back()->with('error', 'Admin session is invalid. Please login again.');
        }

        if (!Hash::check($request->current_password, $admin->password)) {
            return back()->with('error', 'Current password is incorrect.');
        }

        EmailOtp::where('user_id', $admin->id)
            ->where('purpose', 'change_password')
            ->where('is_used', false)
            ->update(['is_used' => true]);

        $otpCode = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

        EmailOtp::create([
            'user_id' => $admin->id,
            'email' => $admin->email,
            'otp_code' => $otpCode,
            'purpose' => 'change_password',
            'expires_at' => now()->addMinutes(5),
            'is_used' => false,
        ]);

        Mail::raw(
            "Your Blood Donor Finder admin change password OTP is: {$otpCode}. This code will expire in 5 minutes.",
            function ($message) use ($admin) {
                $message->to($admin->email)->subject('Admin Change Password OTP');
            }
        );

        return back()->with('success', 'OTP sent to your admin email.');
    }

    public function changePassword(Request $request)
    {
        $this->checkAdminSession();

        $request->validate([
            'otp_code' => 'required|string|size:6',
            'new_password' => 'required|min:6|same:confirm_password',
            'confirm_password' => 'required|min:6',
        ]);

        $admin = User::where('id', Session::get('admin_id'))
            ->where('role', 'admin')
            ->first();

        if (!$admin) {
            return back()->with('error', 'Admin session is invalid. Please login again.');
        }

        $otp = EmailOtp::where('user_id', $admin->id)
            ->where('email', $admin->email)
            ->where('purpose', 'change_password')
            ->where('otp_code', $request->otp_code)
            ->where('is_used', false)
            ->latest()
            ->first();

        if (!$otp) {
            return back()->with('error', 'Invalid OTP.');
        }

        if (now()->gt($otp->expires_at)) {
            return back()->with('error', 'OTP expired.');
        }

        $admin->password = Hash::make($request->new_password);
        $admin->save();

        $otp->is_used = true;
        $otp->save();

        EmailOtp::where('user_id', $admin->id)
            ->where('purpose', 'change_password')
            ->where('is_used', false)
            ->update(['is_used' => true]);

        return back()->with('success', 'Admin password changed successfully.');
    }

    private function checkAdminSession()
    {
        if (!Session::has('admin_id')) {
            abort(403, 'Unauthorized. Please login as admin.');
        }
    }

    public function markNotificationRead($id)
    {
        $this->checkAdminSession();

        Notification::where('id', $id)
            ->where('user_id', Session::get('admin_id'))
            ->update(['is_read' => true]);

        return redirect('/admin/pending-users')->with('success', 'Notification marked as read.');
    }
}