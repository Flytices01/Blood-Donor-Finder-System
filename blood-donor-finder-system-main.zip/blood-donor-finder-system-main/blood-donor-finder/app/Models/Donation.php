<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Donation extends Model
{
    protected $fillable = [
        'donor_id',
        'request_id',
        'donation_date',
        'remarks'
    ];

    public function donor()
    {
        return $this->belongsTo(User::class, 'donor_id');
    }

    public function request()
    {
        return $this->belongsTo(BloodRequest::class, 'request_id');
    }
}