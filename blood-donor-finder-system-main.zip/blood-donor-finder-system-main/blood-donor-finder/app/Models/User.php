<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use App\Models\BloodRequest;
use App\Models\Donation;
use App\Models\Notification;
use App\Models\Conversation;
use App\Models\Message;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = [
        'user_code',
        'name',
        'first_name',
        'middle_name',
        'last_name',
        'suffix',
        'age',
        'email',
        'is_email_verified',
        'password',
        'role',
        'blood_type',
        'phone',
        'location',
        'id_image',
        'selfie_image',
        'blood_type_test_result',
        'profile_picture',
        'donor_points',
        'account_status',
        'availability'
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'password' => 'hashed',
        'availability' => 'boolean',
        'age' => 'integer',
        'donor_points' => 'integer',
    ];

    public function bloodRequests()
    {
        return $this->hasMany(BloodRequest::class, 'requester_id');
    }

    public function donations()
    {
        return $this->hasMany(Donation::class, 'donor_id');
    }

    public function notifications()
    {
        return $this->hasMany(Notification::class);
    }

    public function requesterConversations()
    {
        return $this->hasMany(Conversation::class, 'requester_id');
    }

    public function donorConversations()
    {
        return $this->hasMany(Conversation::class, 'donor_id');
    }

    public function sentMessages()
    {
        return $this->hasMany(Message::class, 'sender_id');
    }

    public function receivedMessages()
    {
        return $this->hasMany(Message::class, 'receiver_id');
    }
}