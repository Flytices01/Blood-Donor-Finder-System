<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('user_code')->nullable()->unique()->after('id');
        });

        $users = DB::table('users')->orderBy('id')->get();

        foreach ($users as $user) {
            $code = 'BDF-' . date('Y') . '-' . str_pad($user->id, 4, '0', STR_PAD_LEFT);

            DB::table('users')
                ->where('id', $user->id)
                ->update(['user_code' => $code]);
        }
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropUnique(['user_code']);
            $table->dropColumn('user_code');
        });
    }
};