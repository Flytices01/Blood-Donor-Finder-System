<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('conversations', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('blood_request_id')->unique();
            $table->unsignedBigInteger('requester_id');
            $table->unsignedBigInteger('donor_id');
            $table->timestamps();

            $table->foreign('blood_request_id')
                ->references('id')
                ->on('blood_requests')
                ->onDelete('cascade');

            $table->foreign('requester_id')
                ->references('id')
                ->on('users')
                ->onDelete('cascade');

            $table->foreign('donor_id')
                ->references('id')
                ->on('users')
                ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('conversations');
    }
};