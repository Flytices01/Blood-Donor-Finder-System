<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
    Schema::table('blood_requests', function (Blueprint $table) {
        $table->unsignedBigInteger('donor_id')->nullable()->after('requester_id');
    });

    Schema::table('users', function (Blueprint $table) {
        $table->integer('donor_points')->default(0);
    });
    }

    public function down()
    {
    Schema::table('blood_requests', function (Blueprint $table) {
        $table->dropColumn('donor_id');
    });

    Schema::table('users', function (Blueprint $table) {
        $table->dropColumn('donor_points');
    });
    }
};
