<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('role')->default('requester');
            $table->string('blood_type')->nullable();
            $table->string('phone')->nullable();
            $table->string('location')->nullable();
            $table->string('id_image')->nullable();
            $table->string('selfie_image')->nullable();
            $table->string('account_status')->default('Pending');
            $table->boolean('availability')->default(true);
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'role',
                'blood_type',
                'phone',
                'location',
                'id_image',
                'selfie_image',
                'account_status',
                'availability'
            ]);
        });
    }
};
