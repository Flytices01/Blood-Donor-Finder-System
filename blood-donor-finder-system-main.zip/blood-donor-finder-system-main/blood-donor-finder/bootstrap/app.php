<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->validateCsrfTokens(except: [
            'login',
            'register',

            // OTP routes
            'send-register-otp',
            'verify-register-otp',
            'send-forgot-password-otp',
            'verify-forgot-password-otp',
            'send-change-password-otp',
            'verify-change-password-otp',

            // Account/profile routes
            'change-password',
            'forgot-password',
            'update-phone-number',
            'upload-profile-picture',
            'user-profile/*',

            // Messages Routes
            'chat/conversation',
            'chat/conversations',
            'chat/conversations/*/messages',
            'chat/conversations/*/mark-read',
            'chat/unread-count',

            // Blood request routes
            'blood-requests',
            'update-blood-request',
            'delete-blood-request',
            'accept-blood-request',
            'mark-completed',

            // Donor routes
            'donor/update-availability/*',
            'redeem-reward',

            // Admin routes
            'admin/approve-user/*',
            'admin/reject-user/*',
            'admin/web/approve-user/*',
            'admin/web/reject-user/*',
            'admin/pending-users-data',

            // Notification routes
            'notifications/read/*',
            'notifications/mark-all-read/*',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();