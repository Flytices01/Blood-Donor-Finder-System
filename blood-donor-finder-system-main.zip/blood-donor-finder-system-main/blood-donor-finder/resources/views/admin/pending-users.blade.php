@extends('layouts.admin')

@section('title', 'Pending Users')
@section('page_title', 'Pending Users')

@section('content')

<div class="content-card">

    <form method="GET" class="mb-3 d-flex" style="max-width: 400px;">
        <input type="text" name="search" class="form-control me-2" placeholder="Search user..." value="{{ request('search') }}">
        <button class="btn btn-danger">Search</button>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead style="background:#b71c1c; color:white;">
                <tr>
                    <th>#</th>
                    <th>User Code</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Blood Type</th>
                    <th>Location</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
            @forelse($users as $user)
                <tr>
                    <td>{{ $users->firstItem() + $loop->index }}</td>
                    <td>{{ $user->user_code }}</td>
                    <td>{{ $user->display_name ?? $user->name }}</td>
                    <td>{{ $user->email }}</td>
                    <td><span class="badge bg-danger">{{ $user->blood_type }}</span></td>
                    <td>{{ $user->location }}</td>

                    <td>
                        <div class="d-flex flex-wrap gap-2">
                            <button
                                type="button"
                                class="btn btn-dark btn-sm view-user-btn"
                                data-bs-toggle="modal"
                                data-bs-target="#userPreviewModal"
                                data-name="{{ $user->display_name ?? $user->name }}"
                                data-idimage="{{ $user->id_image ? asset('storage/' . $user->id_image) : '' }}"
                                data-selfie="{{ $user->selfie_image ? asset('storage/' . $user->selfie_image) : '' }}"
                                data-bloodtest="{{ $user->blood_type_test_result ? asset('storage/' . $user->blood_type_test_result) : '' }}"
                            >
                                View
                            </button>

                            <button
                                type="button"
                                class="btn btn-success btn-sm approve-btn"
                                data-bs-toggle="modal"
                                data-bs-target="#approveModal"
                                data-name="{{ $user->display_name ?? $user->name }}"
                                data-url="/admin/web/approve-user/{{ $user->id }}"
                            >
                                Approve
                            </button>

                            <button
                                type="button"
                                class="btn btn-danger btn-sm reject-btn"
                                data-bs-toggle="modal"
                                data-bs-target="#rejectModal"
                                data-name="{{ $user->display_name ?? $user->name }}"
                                data-url="/admin/web/reject-user/{{ $user->id }}"
                            >
                                Reject
                            </button>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="7" class="text-center text-muted">No pending users found.</td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-3">
        <div class="text-muted text-center mb-2">
            Showing {{ $users->firstItem() ?? 0 }} to {{ $users->lastItem() ?? 0 }} of {{ $users->total() }} pending users
        </div>

        <div class="text-center">
            {{ $users->appends(request()->query())->links() }}
        </div>
    </div>

</div>

<!-- VIEW MODAL -->
<div class="modal fade" id="userPreviewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header">
                <h5 class="modal-title" id="modalUserName">User Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <div class="row g-4">
                    <div class="col-md-4">
                        <p class="fw-bold mb-2">ID Image</p>
                        <div class="border rounded p-2 bg-light text-center">
                            <img id="modalIdImage" src="" alt="ID Image" class="img-fluid rounded" style="max-height: 420px; object-fit: contain; cursor: pointer;" onclick="window.open(this.src, '_blank')">
                            <p id="modalIdFallback" class="text-muted mb-0 d-none">No ID image uploaded.</p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <p class="fw-bold mb-2">Selfie</p>
                        <div class="border rounded p-2 bg-light text-center">
                            <img id="modalSelfieImage" src="" alt="Selfie Image" class="img-fluid rounded" style="max-height: 420px; object-fit: contain; cursor: pointer;" onclick="window.open(this.src, '_blank')">
                            <p id="modalSelfieFallback" class="text-muted mb-0 d-none">No selfie uploaded.</p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <p class="fw-bold mb-2">Blood Test Result</p>
                        <div class="border rounded p-2 bg-light text-center">
                            <img id="modalBloodTestImage" src="" alt="Blood Test Result" class="img-fluid rounded" style="max-height: 420px; object-fit: contain; cursor: pointer;" onclick="window.open(this.src, '_blank')">
                            <p id="modalBloodTestFallback" class="text-muted mb-0 d-none">No blood test result uploaded.</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- APPROVE MODAL -->
<div class="modal fade" id="approveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header">
                <h5 class="modal-title">Approve User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <p id="approveModalText" class="mb-0">Are you sure you want to approve this user?</p>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>

                <form id="approveForm" method="POST" action="">
                    @csrf
                    <button type="submit" class="btn btn-success">Approve</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- REJECT MODAL -->
<div class="modal fade" id="rejectModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header">
                <h5 class="modal-title">Reject User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="rejectForm" method="POST" action="">
                @csrf

                <div class="modal-body">
                    <p id="rejectModalText">Are you sure you want to reject this user?</p>

                    <div class="mt-3">
                        <label class="form-label fw-semibold">Reason for rejection</label>
                        <textarea
                            name="reject_reason"
                            class="form-control"
                            rows="4"
                            placeholder="Enter reason here..."
                            required
                        ></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('.view-user-btn');
    const modalUserName = document.getElementById('modalUserName');
    const modalIdImage = document.getElementById('modalIdImage');
    const modalSelfieImage = document.getElementById('modalSelfieImage');
    const modalBloodTestImage = document.getElementById('modalBloodTestImage');

    const modalIdFallback = document.getElementById('modalIdFallback');
    const modalSelfieFallback = document.getElementById('modalSelfieFallback');
    const modalBloodTestFallback = document.getElementById('modalBloodTestFallback');

    viewButtons.forEach(button => {
        button.addEventListener('click', function () {
            const name = this.getAttribute('data-name');
            const idImage = this.getAttribute('data-idimage');
            const selfie = this.getAttribute('data-selfie');
            const bloodTest = this.getAttribute('data-bloodtest');

            modalUserName.textContent = name;

            if (idImage) {
                modalIdImage.src = idImage;
                modalIdImage.classList.remove('d-none');
                modalIdFallback.classList.add('d-none');
            } else {
                modalIdImage.src = '';
                modalIdImage.classList.add('d-none');
                modalIdFallback.classList.remove('d-none');
            }

            if (selfie) {
                modalSelfieImage.src = selfie;
                modalSelfieImage.classList.remove('d-none');
                modalSelfieFallback.classList.add('d-none');
            } else {
                modalSelfieImage.src = '';
                modalSelfieImage.classList.add('d-none');
                modalSelfieFallback.classList.remove('d-none');
            }

            if (bloodTest) {
                modalBloodTestImage.src = bloodTest;
                modalBloodTestImage.classList.remove('d-none');
                modalBloodTestFallback.classList.add('d-none');
            } else {
                modalBloodTestImage.src = '';
                modalBloodTestImage.classList.add('d-none');
                modalBloodTestFallback.classList.remove('d-none');
            }
        });
    });

    const approveButtons = document.querySelectorAll('.approve-btn');
    const approveForm = document.getElementById('approveForm');
    const approveModalText = document.getElementById('approveModalText');

    approveButtons.forEach(button => {
        button.addEventListener('click', function () {
            const name = this.getAttribute('data-name');
            const url = this.getAttribute('data-url');

            approveModalText.textContent = `Are you sure you want to approve ${name}?`;
            approveForm.action = url;
        });
    });

    const rejectButtons = document.querySelectorAll('.reject-btn');
    const rejectForm = document.getElementById('rejectForm');
    const rejectModalText = document.getElementById('rejectModalText');

    rejectButtons.forEach(button => {
        button.addEventListener('click', function () {
            const name = this.getAttribute('data-name');
            const url = this.getAttribute('data-url');

            rejectModalText.textContent = `Are you sure you want to reject ${name}?`;
            rejectForm.action = url;
        });
    });
});
</script>

@endsection