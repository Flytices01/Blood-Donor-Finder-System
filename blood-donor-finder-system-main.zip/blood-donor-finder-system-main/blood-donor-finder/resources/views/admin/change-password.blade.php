@extends('layouts.admin')

@section('title', 'Change Password')
@section('page_title', 'Change Password')

@section('content')

<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="content-card">

            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            @if(session('error'))
                <div class="alert alert-danger">{{ session('error') }}</div>
            @endif

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul class="mb-0 ps-3">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="alert alert-info">
                OTP will be sent to your currently logged-in admin email.
            </div>

            <form method="POST" action="/admin/send-change-password-otp" class="mb-4">
                @csrf

                <div class="mb-3">
                    <label class="form-label fw-semibold">Current Password</label>
                    <input type="password" name="current_password" class="form-control" placeholder="Enter your current password" required>
                </div>

                <button type="submit" class="btn btn-secondary w-100">
                    Send OTP
                </button>
            </form>

            <hr>

            <form method="POST" action="/admin/change-password">
                @csrf

                <div class="mb-3">
                    <label class="form-label fw-semibold">OTP Code</label>
                    <input type="text" name="otp_code" class="form-control" placeholder="Enter OTP" maxlength="6" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">New Password</label>
                    <input type="password" name="new_password" class="form-control" placeholder="Enter new password" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password" required>
                </div>

                <button type="submit" class="btn btn-danger w-100">
                    Change Password
                </button>
            </form>

        </div>
    </div>
</div>

@endsection