@extends('layouts.admin')

@section('title', 'Donors')
@section('page_title', 'Donors')

@section('content')

<div class="content-card">

    <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
        <form method="GET" action="/admin/donors" class="d-flex" style="max-width: 420px; width: 100%;">
            <input
                type="text"
                name="search"
                class="form-control me-2"
                placeholder="Search donor name, email, blood type, location..."
                value="{{ request('search') }}"
            >
            <button type="submit" class="btn btn-danger">Search</button>
        </form>

        @if(request('search'))
            <a href="/admin/donors" class="btn btn-outline-secondary mt-2 mt-md-0">Reset</a>
        @endif
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead style="background: #b71c1c; color: white;">
                <tr>
                    <th>#</th>
                    <th>User Code</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Blood Type</th>
                    <th>Phone</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th>Availability</th>
                </tr>
            </thead>

            <tbody>
                @forelse($donors as $donor)
                    <tr>
                        <td>{{ $donors->firstItem() + $loop->index }}</td>
                        <td>{{ $donor->user_code }}</td>
                        <td>{{ $donor->name }}</td>
                        <td>{{ $donor->email }}</td>
                        <td>
                            <span class="badge bg-danger">{{ $donor->blood_type }}</span>
                        </td>
                        <td>{{ $donor->phone }}</td>
                        <td>{{ $donor->location }}</td>
                        <td>
                            @if($donor->account_status === 'Approved')
                                <span class="badge bg-success">Approved</span>
                            @elseif($donor->account_status === 'Pending')
                                <span class="badge bg-warning text-dark">Pending</span>
                            @elseif($donor->account_status === 'Rejected')
                                <span class="badge bg-danger">Rejected</span>
                            @else
                                <span class="badge bg-secondary">{{ $donor->account_status }}</span>
                            @endif
                        </td>
                        <td>
                            @if($donor->availability)
                                <span class="badge bg-primary">Available</span>
                            @else
                                <span class="badge bg-secondary">Not Available</span>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="9" class="text-center text-muted">No donors found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="text-center mt-3">
        <div class="text-muted mb-2">
            Showing {{ $donors->firstItem() ?? 0 }} to {{ $donors->lastItem() ?? 0 }} of {{ $donors->total() }} donors
        </div>

        <div>
            {{ $donors->links() }}
        </div>
    </div>

</div>

@endsection