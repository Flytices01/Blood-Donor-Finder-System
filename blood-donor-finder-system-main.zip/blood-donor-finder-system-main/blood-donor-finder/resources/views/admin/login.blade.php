<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | Blood Donor Finder</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #e5dfdf, #e5dfdf);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-wrapper {
            width: 100%;
            max-width: 420px;
        }

        .login-card {
            background: #ffffff;
            border-radius: 16px;
            padding: 35px 30px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        .logo-img {
            width: 250px;
            height: auto;
            margin: 0 auto 15px;
            display: block;
        }

        .title {
            text-align: center;
            font-size: 26px;
            font-weight: bold;
            color: #b71c1c;
            margin-bottom: 8px;
        }

        .subtitle {
            text-align: center;
            font-size: 14px;
            color: #666;
            margin-bottom: 25px;
        }

        .error-box {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ef9a9a;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 18px;
            font-size: 14px;
            text-align: left;
        }

        .form-group {
            margin-bottom: 18px;
            text-align: left;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: bold;
            color: #444;
        }

        .form-input {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-size: 14px;
            outline: none;
            transition: 0.2s ease;
        }

        .form-input:focus {
            border-color: #d32f2f;
            box-shadow: 0 0 0 3px rgba(211, 47, 47, 0.15);
        }

        .password-wrapper {
            position: relative;
        }

        .toggle-password {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #777;
            font-size: 13px;
            user-select: none;
        }

        .login-btn {
            width: 100%;
            padding: 13px;
            background: #d32f2f;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.2s ease;
        }

        .login-btn:hover {
            background: #b71c1c;
        }

        .footer-text {
            margin-top: 20px;
            text-align: center;
            font-size: 13px;
            color: #777;
        }

        @media (max-width: 480px) {
            .login-card {
                padding: 28px 20px;
            }

            .title {
                font-size: 22px;
            }
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="login-card">

            <img src="{{ asset('images/bdf_logo.jpg') }}" alt="Blood Donor Finder Logo" class="logo-img">
            

            <div class="title">Admin Login</div>
            <div class="subtitle">Blood Donor Finder Admin Panel</div>

            @if(session('error'))
                <div class="error-box">
                    {{ session('error') }}
                </div>
            @endif

            <form method="POST" action="/admin/login">
                @csrf

                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-input" placeholder="Enter email" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="password" name="password" class="form-input" placeholder="Enter password" required>
                        <span class="toggle-password" onclick="togglePassword()">Show</span>
                    </div>
                </div>

                <button type="submit" class="login-btn">Login</button>
            </form>

            <div class="footer-text">
                Secure access for authorized administrators only
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleText = document.querySelector('.toggle-password');

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleText.innerText = 'Hide';
            } else {
                passwordInput.type = 'password';
                toggleText.innerText = 'Show';
            }
        }
    </script>
</body>
</html>