@extends('layouts.admin')

@section('title', 'Blood Requests')
@section('page_title', 'Blood Requests')

@section('content')

<div class="content-card">

    <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
        <form method="GET" action="/admin/blood-requests" class="d-flex" style="max-width: 420px; width: 100%;">
            <input
                type="text"
                name="search"
                class="form-control me-2"
                placeholder="Search requester, blood type, hospital..."
                value="{{ request('search') }}"
            >
            <button type="submit" class="btn btn-danger">Search</button>
        </form>

        @if(request('search'))
            <a href="/admin/blood-requests" class="btn btn-outline-secondary mt-2 mt-md-0">Reset</a>
        @endif
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead style="background: #b71c1c; color: white;">
                <tr>
                    <th>#</th>
                    <th>User Code</th>
                    <th>Requester</th>
                    <th>Blood Type</th>
                    <th>Hospital</th>
                    <th>Location</th>
                    <th>Contact</th>
                    <th>Urgency</th>
                    <th>Status</th>
                </tr>
            </thead>

            <tbody>
                @forelse($requests as $request)
                    <tr>
                        <td>{{ $requests->firstItem() + $loop->index }}</td>
                        <td>{{ $request->requester->user_code ?? 'N/A' }}</td>
                        <td>{{ $request->requester->name ?? 'N/A' }}</td>
                        <td><span class="badge bg-danger">{{ $request->blood_type }}</span></td>
                        <td>{{ $request->hospital_name }}</td>
                        <td>{{ $request->location }}</td>
                        <td>{{ $request->contact_number }}</td>

                        <td>
                            @php $urgency = strtolower($request->urgency_level); @endphp

                            @if($urgency === 'critical')
                                <span class="badge bg-dark">Critical</span>
                            @elseif($urgency === 'high')
                                <span class="badge bg-danger">High</span>
                            @elseif($urgency === 'medium')
                                <span class="badge bg-warning text-dark">Medium</span>
                            @elseif($urgency === 'low')
                                <span class="badge bg-secondary">Low</span>
                            @else
                                <span class="badge bg-info text-dark">{{ $request->urgency_level }}</span>
                            @endif
                        </td>

                        <td>
                            @php $status = strtolower($request->status ?? 'pending'); @endphp

                            @if($status === 'approved')
                                <span class="badge bg-success">Approved</span>
                            @elseif($status === 'rejected')
                                <span class="badge bg-danger">Rejected</span>
                            @elseif($status === 'completed')
                                <span class="badge bg-primary">Completed</span>
                            @else
                                <span class="badge bg-warning text-dark">Pending</span>
                            @endif
                        </td>
                    </tr>

                @empty
                    <tr>
                        <td colspan="9" class="text-center text-muted">No blood requests found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-3">
        <div class="text-muted text-center mb-2">
            Showing {{ $requests->firstItem() ?? 0 }} to {{ $requests->lastItem() ?? 0 }} of {{ $requests->total() }} blood requests
        </div>

        <div class="text-center">
            {{ $requests->links() }}
        </div>
    </div>

</div>

@endsection