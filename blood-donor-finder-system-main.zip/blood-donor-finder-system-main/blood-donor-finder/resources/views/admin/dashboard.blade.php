@extends('layouts.admin')

@section('title', 'Dashboard')
@section('page_title', 'Dashboard')

@section('content')

<div class="mb-4">
    <div class="content-card" style="background: linear-gradient(135deg, #d32f2f, #9a0007); color: white;">
        <h3 class="mb-2">Welcome, {{ session('admin_name') }}</h3>
        <p class="mb-0">Manage users, blood requests, donor records, and account verification from one dashboard.</p>
    </div>
</div>

<div class="row g-4">

    <div class="col-md-6 col-lg-4">
        <div class="content-card h-100">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <p class="text-muted mb-1">Total Users</p>
                    <h2 class="mb-0">{{ $totalUsers }}</h2>
                </div>
                <div class="fs-1 text-danger">
                    <i class="bi bi-people-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-4">
        <div class="content-card h-100">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <p class="text-muted mb-1">Pending Users</p>
                    <h2 class="mb-0">{{ $pendingUsers }}</h2>
                </div>
                <div class="fs-1 text-warning">
                    <i class="bi bi-person-lines-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-4">
        <div class="content-card h-100">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <p class="text-muted mb-1">Approved Users</p>
                    <h2 class="mb-0">{{ $approvedUsers }}</h2>
                </div>
                <div class="fs-1 text-success">
                    <i class="bi bi-person-check-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-4">
        <div class="content-card h-100">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <p class="text-muted mb-1">Blood Requests</p>
                    <h2 class="mb-0">{{ $bloodRequests }}</h2>
                </div>
                <div class="fs-1 text-danger">
                    <i class="bi bi-droplet-half"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-4">
        <div class="content-card h-100">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <p class="text-muted mb-1">Donors</p>
                    <h2 class="mb-0">{{ $donors }}</h2>
                </div>
                <div class="fs-1 text-primary">
                    <i class="bi bi-heart-pulse-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-4">
        <div class="content-card h-100">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <p class="text-muted mb-1">Notifications</p>
                    <h2 class="mb-0">{{ $notifications }}</h2>
                </div>
                <div class="fs-1 text-secondary">
                    <i class="bi bi-bell-fill"></i>
                </div>
            </div>
        </div>
    </div>

</div>

<div class="row g-4 mt-1">
    <div class="col-lg-8">
        <div class="content-card h-100">
            <h5 class="mb-3">Admin Overview</h5>
            <p class="text-muted mb-2">
                This admin dashboard helps monitor account approvals, donor records, and submitted blood requests.
            </p>
            <p class="text-muted mb-0">
                Use the sidebar to navigate between pending users, donor information, blood requests, and password management.
            </p>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="content-card h-100">
            <h5 class="mb-3">Quick Actions</h5>

            <div class="d-grid gap-2">
                <a href="/admin/pending-users" class="btn btn-outline-danger">View Pending Users</a>
                <a href="/admin/blood-requests" class="btn btn-outline-danger">View Blood Requests</a>
                <a href="/admin/donors" class="btn btn-outline-danger">View Donors</a>
            </div>
        </div>
    </div>
</div>

@endsection