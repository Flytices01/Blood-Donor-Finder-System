<!DOCTYPE html>
<html>
<head>
    <title>@yield('title') - Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        .sidebar {
            width: 260px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #d32f2f, #9a0007);
            color: white;
            padding: 22px 18px;
            box-shadow: 4px 0 12px rgba(0,0,0,0.15);
            overflow-y: auto;
        }

        .logo-box {
            width: 100%;
            background: #ffffff;
            border-radius: 18px;
            padding: 14px 12px;
            margin: 0 auto 18px;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 8px 18px rgba(0,0,0,0.18);
        }

        .logo-box img {
            width: 180px;
            max-width: 100%;
            height: auto;
            display: block;
            object-fit: contain;
        }

        .sidebar h4 {
            text-align: center;
            margin: 0 0 22px;
            font-size: 20px;
            font-weight: 700;
            color: #ffffff;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 14px;
            border-radius: 10px;
            color: #ffeaea;
            text-decoration: none;
            margin-bottom: 8px;
            transition: 0.2s ease;
            font-size: 16px;
        }

        .sidebar a:hover {
            background: rgba(255,255,255,0.25);
            color: white;
            transform: translateX(4px);
        }

        .sidebar a.active {
            background: white;
            color: #b71c1c;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }

        .content {
            margin-left: 260px;
            padding: 25px;
        }

        .topbar .btn {
            border-radius: 10px;
            background: #ffffff;
            border: none;
            padding: 10px 14px;
        }

        .topbar .dropdown-menu {
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 24px rgba(0,0,0,0.12);
        }

        .topbar .dropdown-item {
            white-space: normal;
            padding: 10px 12px;
        }

        .topbar .dropdown-item:hover {
            background: #f8f9fa;
        }

        .page-title {
            font-size: 40px;
            font-weight: 700;
            margin-bottom: 18px;
            color: #222;
        }

        .content-card {
            background: white;
            padding: 20px;
            border-radius: 14px;
            box-shadow: 0 6px 16px rgba(0,0,0,0.10);
            transition: 0.2s ease;
        }

        .content-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.12);
        }

        .table {
            margin-bottom: 0;
        }

        .table thead th {
            vertical-align: middle;
            font-weight: 600;
        }

        .table td, .table th {
            padding: 14px 12px;
        }

        .badge {
            font-size: 13px;
            padding: 8px 10px;
            border-radius: 8px;
        }

        .btn {
            border-radius: 8px;
        }

        .form-control {
            border-radius: 8px;
        }

        .alert {
            border-radius: 10px;
        }

        .pagination {
            justify-content: center;
            margin-bottom: 0;
        }

        .pagination .page-link {
            padding: 6px 12px;
            font-size: 14px;
            border-radius: 6px;
        }

        .pagination .page-item.active .page-link {
            background-color: #d32f2f;
            border-color: #d32f2f;
        }

        @media (max-width: 991px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .content {
                margin-left: 0;
                padding: 18px;
            }

            .page-title {
                font-size: 30px;
            }
        }
    </style>
</head>

<body>

@php
    use App\Models\Notification;
    use Illuminate\Support\Facades\Session;

    $adminNotificationCount = 0;
    $adminNotifications = collect();

    if (Session::has('admin_id')) {
        $adminNotificationCount = Notification::where('user_id', Session::get('admin_id'))
            ->where('is_read', false)
            ->count();

        $adminNotifications = Notification::where('user_id', Session::get('admin_id'))
            ->where('is_read', false)
            ->latest()
            ->take(5)
            ->get();
    }
@endphp

<div class="sidebar">

    <div class="logo-box">
        <img src="{{ asset('images/bdf_logo.png') }}" alt="Blood Donor Finder Logo">
    </div>

    <h4>Admin Panel</h4>

    <a href="/admin/dashboard" class="{{ request()->is('admin/dashboard') ? 'active' : '' }}">
        <i class="bi bi-speedometer2"></i> Dashboard
    </a>

    <a href="/admin/pending-users" class="{{ request()->is('admin/pending-users') ? 'active' : '' }}">
        <i class="bi bi-person-lines-fill"></i> Pending Users
    </a>

    <a href="/admin/blood-requests" class="{{ request()->is('admin/blood-requests') ? 'active' : '' }}">
        <i class="bi bi-droplet"></i> Blood Requests
    </a>

    <a href="/admin/donors" class="{{ request()->is('admin/donors') ? 'active' : '' }}">
        <i class="bi bi-people"></i> Donors
    </a>

    <a href="/admin/change-password" class="{{ request()->is('admin/change-password') ? 'active' : '' }}">
        <i class="bi bi-lock"></i> Change Password
    </a>

    <a href="/admin/logout">
        <i class="bi bi-box-arrow-right"></i> Logout
    </a>

</div>

<div class="content">

    <div class="topbar d-flex justify-content-end align-items-center mb-3">
        <div class="dropdown">
            <button class="btn btn-light position-relative shadow-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-bell-fill fs-5 text-danger"></i>

                @if($adminNotificationCount > 0)
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        {{ $adminNotificationCount }}
                    </span>
                @endif
            </button>

            <ul class="dropdown-menu dropdown-menu-end p-2" style="width: 350px;">
                <li class="fw-bold px-2 py-1 border-bottom mb-2">Unread Notifications</li>

                @forelse($adminNotifications as $notification)
                    <li class="mb-2">
                        <a href="{{ route('admin.notifications.read', $notification->id) }}" class="dropdown-item rounded">
                            <div class="fw-semibold">{{ $notification->title }}</div>
                            <div class="small text-muted">{{ $notification->message }}</div>
                            <div class="small text-secondary mt-1">{{ $notification->created_at->diffForHumans() }}</div>
                        </a>
                    </li>
                @empty
                    <li class="dropdown-item text-muted">No unread notifications.</li>
                @endforelse
            </ul>
        </div>
    </div>

    <div class="page-title">@yield('page_title')</div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    @yield('content')

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>