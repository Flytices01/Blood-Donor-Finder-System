<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\DonorController;
use App\Http\Controllers\Api\BloodRequestController;
use App\Http\Controllers\Api\AdminController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\AdminWebController;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\Api\ChatController;
use App\Http\Controllers\Api\RewardController;

Route::get('/test', function () {
    return 'Working!';
});

Route::get('/login', function () {
    return 'Use POST method for login';
});

Route::get('/register-test', function () {
    return '
    <h2>Register Test Form</h2>
    <form method="POST" action="/register" enctype="multipart/form-data">
        <input type="hidden" name="_token" value="' . csrf_token() . '">

        <input name="name" placeholder="Name" required><br><br>
        <input name="email" placeholder="Email" required><br><br>
        <input name="password" placeholder="Password" required><br><br>

        <label>Role:</label><br>
        <select name="role" required>
            <option value="">Select Role</option>
            <option value="donor">Donor</option>
            <option value="requester">Requester</option>
        </select><br><br>

        <label>Blood Type:</label><br>
        <select name="blood_type" required>
            <option value="">Select Blood Type</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
        </select><br><br>

        <input name="phone" placeholder="Phone" required><br><br>
        <input name="location" placeholder="Location" required><br><br>

        <label>Upload ID Image:</label><br>
        <input type="file" name="id_image" accept="image/*" required><br><br>

        <label>Upload Selfie Image:</label><br>
        <input type="file" name="selfie_image" accept="image/*" required><br><br>

        <label>Upload Blood Type Test Result:</label><br>
        <input type="file" name="blood_type_test_result" accept="image/*" required><br><br>

        <button type="submit">Register</button>
    </form>
    ';
});

Route::get('/login-test', function () {
    return '
    <h2>Login Test</h2>
    <form method="POST" action="/login">
        <input type="hidden" name="_token" value="' . csrf_token() . '">
        <input name="email" placeholder="Email"><br><br>
        <input name="password" placeholder="Password"><br><br>
        <button type="submit">Login</button>
    </form>
    ';
});

Route::get('/donor-search-test', function () {
    return '
    <h2>Donor Search Test</h2>
    <form method="GET" action="/donors/search">
        <input name="blood_type" placeholder="Blood Type"><br><br>
        <input name="location" placeholder="Location"><br><br>
        <button type="submit">Search Donors</button>
    </form>
    ';
});

Route::get('/blood-request-test', function () {
    return '
    <h2>Blood Request Test</h2>
    <form method="POST" action="/blood-requests">
        <input type="hidden" name="_token" value="' . csrf_token() . '">
        <input name="requester_id" placeholder="Requester ID"><br><br>
        <input name="blood_type" placeholder="Blood Type"><br><br>
        <input name="hospital_name" placeholder="Hospital Name"><br><br>
        <input name="location" placeholder="Location"><br><br>
        <input name="contact_number" placeholder="Contact Number"><br><br>
        <input name="urgency_level" placeholder="Urgency Level"><br><br>
        <textarea name="notes" placeholder="Notes"></textarea><br><br>
        <button type="submit">Submit Blood Request</button>
    </form>
    ';
});

Route::get('/availability-test', function () {
    return '
    <h2>Availability Test</h2>
    <form method="POST" action="/donor/update-availability/1">
        <input type="hidden" name="_token" value="' . csrf_token() . '">
        <input name="availability" placeholder="1 or 0"><br><br>
        <button type="submit">Update Availability</button>
    </form>
    ';
});

Route::get('/notifications-test/1', function () {
    return redirect('/notifications/1');
});

Route::get('/admin/pending-users-view', [AdminController::class, 'pendingUsersView']);

Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

Route::get('/donors', [DonorController::class, 'index']);
Route::get('/donors/search', [DonorController::class, 'search']);
Route::post('/donor/update-availability/{id}', [DonorController::class, 'updateAvailability']);

Route::post('/blood-requests', [BloodRequestController::class, 'store']);
Route::get('/blood-requests', [BloodRequestController::class, 'index']);
Route::get('/blood-requests/{id}', [BloodRequestController::class, 'show']);
Route::post('/update-blood-request', [BloodRequestController::class, 'update']);
Route::post('/delete-blood-request', [BloodRequestController::class, 'delete']);

Route::get('/admin/pending-users', [AdminController::class, 'pendingUsers']);
Route::post('/admin/approve-user/{id}', [AdminController::class, 'approveUser']);
Route::post('/admin/reject-user/{id}', [AdminController::class, 'rejectUser']);

Route::get('/notifications/{userId}', [NotificationController::class, 'index']);
Route::post('/notifications/{id}/read', [NotificationController::class, 'markAsRead']);

Route::post('/change-password', [AuthController::class, 'changePassword']);
Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
Route::post('/update-phone-number', [AuthController::class, 'updatePhoneNumber']);
Route::post('/upload-profile-picture', [AuthController::class, 'uploadProfilePicture']);

Route::post('/blood-requests', [BloodRequestController::class, 'store']);
Route::get('/blood-requests', [BloodRequestController::class, 'index']);
Route::get('/blood-requests/{id}', [BloodRequestController::class, 'show']);
Route::post('/update-blood-request', [BloodRequestController::class, 'update']);
Route::post('/delete-blood-request', [BloodRequestController::class, 'destroy']);
Route::post('/accept-blood-request', [BloodRequestController::class, 'acceptRequest']);
Route::post('/mark-completed', [BloodRequestController::class, 'markCompleted']);
Route::get('/user-profile/{id}', [AuthController::class, 'getUserProfile']);
Route::post('/notifications/mark-all-read/{userId}', [App\Http\Controllers\Api\NotificationController::class, 'markAllAsRead']);

Route::post('/chat/conversation', [ChatController::class, 'getOrCreateConversation']);
Route::get('/chat/conversations', [ChatController::class, 'getChatList']);
Route::get('/chat/conversations/{conversationId}/messages', [ChatController::class, 'getMessages']);
Route::post('/chat/conversations/{conversationId}/messages', [ChatController::class, 'sendMessage']);
Route::post('/chat/conversations/{conversationId}/mark-read', [ChatController::class, 'markAsRead']);
Route::get('/chat/unread-count', [ChatController::class, 'unreadCount']);

Route::post('/redeem-reward', [RewardController::class, 'redeemReward']);

/*
Admin Web Panel Routes
*/

Route::get('/admin/login', [AdminWebController::class, 'showLogin']);
Route::post('/admin/login', [AdminWebController::class, 'login']);
Route::get('/admin/logout', [AdminWebController::class, 'logout']);

Route::get('/admin/dashboard', [AdminWebController::class, 'dashboard']);
Route::get('/admin/pending-users', [AdminWebController::class, 'pendingUsers']);
Route::get('/admin/pending-users-data', [AdminController::class, 'getPendingUsersData']);
Route::get('/admin/blood-requests', [AdminWebController::class, 'bloodRequests']);
Route::get('/admin/donors', [AdminWebController::class, 'donors']);

Route::post('/admin/web/approve-user/{id}', [AdminWebController::class, 'approveUser']);
Route::post('/admin/web/reject-user/{id}', [AdminWebController::class, 'rejectUser']);

Route::get('/admin/change-password', [AdminWebController::class, 'showChangePassword']);
Route::post('/admin/change-password', [AdminWebController::class, 'changePassword']);
Route::get('/admin/notifications/read/{id}', [AdminWebController::class, 'markNotificationRead'])->name('admin.notifications.read');
Route::post('/admin/send-change-password-otp', [AdminWebController::class, 'sendChangePasswordOtp']);


Route::get('/test-email', function () {
    Mail::raw('This is a test email from Blood Donor Finder.', function ($message) {
        $message->to('blooddonorfinder@gmail.com')
                ->subject('Test Email');
    });

    return 'Test email sent successfully.';
});

Route::post('/send-register-otp', [AuthController::class, 'sendRegisterOtp']);
Route::post('/verify-register-otp', [AuthController::class, 'verifyRegisterOtp']);
Route::post('/send-forgot-password-otp', [AuthController::class, 'sendForgotPasswordOtp']);
Route::post('/verify-forgot-password-otp', [AuthController::class, 'verifyForgotPasswordOtp']);
Route::post('/send-change-password-otp', [AuthController::class, 'sendChangePasswordOtp']);
Route::post('/verify-change-password-otp', [AuthController::class, 'verifyChangePasswordOtp']);

Route::get('/otp-test', function () {
    return '
    <h2>OTP Verification Test</h2>

    <form method="POST" action="/verify-register-otp">
        <input type="hidden" name="_token" value="'.csrf_token().'">

        <label>Email:</label><br>
        <input type="text" name="email" placeholder="Enter email"><br><br>

        <label>OTP Code:</label><br>
        <input type="text" name="otp_code" placeholder="Enter OTP"><br><br>

        <button type="submit">Verify OTP</button>
    </form>
    ';
});

Route::get('/chat-test', function () {
    return '
    <h2>Chat Test - Create/Get Conversation</h2>
    <form method="POST" action="/chat/conversation">
        <input type="hidden" name="_token" value="' . csrf_token() . '">
        <input name="blood_request_id" placeholder="Blood Request ID" required><br><br>
        <input name="user_id" placeholder="User ID (requester or donor)" required><br><br>
        <button type="submit">Create / Get Conversation</button>
    </form>

    <hr>

    <h2>Send Message Test</h2>
    <form method="POST" action="/chat/conversations/1/messages">
        <input type="hidden" name="_token" value="' . csrf_token() . '">
        <input name="sender_id" placeholder="Sender ID" required><br><br>
        <textarea name="message" placeholder="Type message here" required></textarea><br><br>
        <button type="submit">Send Message to Conversation 1</button>
    </form>

    <hr>

    <h2>Mark As Read Test</h2>
    <form method="POST" action="/chat/conversations/1/mark-read">
        <input type="hidden" name="_token" value="' . csrf_token() . '">
        <input name="user_id" placeholder="Receiver User ID" required><br><br>
        <button type="submit">Mark Read in Conversation 1</button>
    </form>

    <hr>

    <h2>Quick Links</h2>
    <p><a href="/chat/conversations?user_id=1" target="_blank">View Chat List for User 1</a></p>
    <p><a href="/chat/conversations/1/messages?user_id=1" target="_blank">View Messages for Conversation 1 as User 1</a></p>
    <p><a href="/chat/unread-count?user_id=1" target="_blank">View Unread Count for User 1</a></p>
    ';
});